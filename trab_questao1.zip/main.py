#! /usr/bin/env python3
import cv2
import numpy as np
from nav_msgs.msg import *
from sensor_msgs.msg import *
import rospy
from geometry_msgs.msg import Twist  # tópico cmd_vel
import time
import sys
from math import atan2, sqrt, cos, sin
from celula import Celula  # carrega estrutura de dados criada para celula
from Vetor_o import Vetor # carrega estrura para a matriz O do algoritmo A*
from matplotlib import pyplot as plt
from tf.transformations import euler_from_quaternion

global vetor_conj_o
global vetor_conj_c
global matriz_celula
global vetor_caminho

#O cenário possui 100 pixels (altura) x 120 pixels (largura)

#Esta função retorna os índices da célula
def calcula_coord_pixel(coord_pixel_y, coord_pixel_x):
    print(' Ínicio cálculo do índices da célula')
    aux1_x = 0
    while aux1_x <= 11:
        aux1_y = 0
        while aux1_y <= 9:
            if (matriz_celula[aux1_y][aux1_x].coord_x - 5) <= (coord_pixel_x) and (coord_pixel_x) <= (
                    matriz_celula[aux1_y][aux1_x].coord_x + 4):
                if (matriz_celula[aux1_y][aux1_x].coord_y - 5) <= (coord_pixel_y) and (coord_pixel_y) <= (
                        matriz_celula[aux1_y][aux1_x].coord_y + 4):
                    print('     Indices da celula destino (x,y): (', aux1_x, ',', aux1_y, ')')
                    return aux1_y, aux1_x
            aux1_y += 1
        aux1_x += 1

#Preenche função h acima
def preenche_acima_h(coluna_y, linha_x):  # esta função irá preencher h das celulas acima
    while coluna_y > 0 and matriz_celula[coluna_y][linha_x].h != None: #and matriz_celula[coluna_y][linha_x].obstaculo == 0
        #if matriz_celula[coluna_y - 1][linha_x].obstaculo == 0:
        matriz_celula[coluna_y - 1][linha_x].h = matriz_celula[coluna_y][linha_x].h + 1
        coluna_y -= 1
        #else:
            #coluna_y = 0

#Preenche a função h abaixo
def preenche_abaixo_h(coluna_y, linha_x):  # esta função irá preencher a função h das celulas a esquerda
    while coluna_y < 9 and matriz_celula[coluna_y][linha_x].h != None: #and matriz_celula[coluna_y][linha_x].obstaculo == 0
        #if matriz_celula[coluna_y + 1][linha_x].obstaculo == 0:
        matriz_celula[coluna_y + 1][linha_x].h = matriz_celula[coluna_y][linha_x].h + 1
        coluna_y += 1
        #else:
        #    coluna_y = 9

#preenche a função h a esquerda
def preenche_a_esquerda_h(coluna_y, linha_x):  # esta função irá preencher a função h das celulas a esquerda
    while linha_x > 0 and matriz_celula[coluna_y][linha_x].h != None: #matriz_celula[coluna_y][linha_x].obstaculo == 0
        #if matriz_celula[coluna_y][linha_x - 1].obstaculo == 0:
        matriz_celula[coluna_y][linha_x - 1].h = matriz_celula[coluna_y][linha_x].h + 1
        linha_x -= 1


#Prenche a função h a direita
def preenche_a_direita_h(coluna_y, linha_x):  # esta função irá preencher a função h para as células a direita
    while linha_x < 11 and matriz_celula[coluna_y][linha_x].h != None: #and matriz_celula[coluna_y][linha_x].obstaculo == 0
       # if matriz_celula[coluna_y][linha_x + 1].obstaculo == 0:
        matriz_celula[coluna_y][linha_x + 1].h = matriz_celula[coluna_y][linha_x].h + 1
        linha_x += 1
        #else:
            #linha_x = 29

def busca_celula_peso_esquerda_h(coluna_y, linha_x):  # esta função busca a primeira celula com peso a esquerda
    dist = 0
    achou = 0
    if linha_x != 0:  # se linha_x==0 nao faz sentido procurar celulas a esquerda
        while matriz_celula[coluna_y][linha_x].h == None and linha_x > 0 and matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].h == None:
                dist += 1
            linha_x -= 1
        if matriz_celula[coluna_y][linha_x].h != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x

def busca_celula_peso_direita_h(coluna_y, linha_x):  # esta função busca a primeira celula com peso a direita
    dist = 0
    achou = 0
    if linha_x != 29:  # se linha_x==29 nao faz sentido procurar celulas a direita
        while matriz_celula[coluna_y][linha_x].h == None and linha_x <= 29 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].h == None:
                dist += 1
            linha_x += 1
        if matriz_celula[coluna_y][linha_x].h != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x

def busca_celula_peso_acima_h(coluna_y, linha_x):  # esta função busca a primeira celula com peso, acima
    dist = 0
    achou = 0
    if coluna_y != 0:  # se coluna_y==0 nao faz sentido procurar celulas acima
        while matriz_celula[coluna_y][linha_x].h == None and coluna_y >= 0 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].h == None:
                dist += 1
            coluna_y -= 1
        if matriz_celula[coluna_y][linha_x].h != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x

def busca_celula_peso_abaixo_h(coluna_y, linha_x):  # esta função busca a primeira celula com peso, abaixo
    dist = 0
    achou = 0
    if coluna_y != 29:  # se coluna_y==29 nao faz sentido procurar celulas abaixo
        while matriz_celula[coluna_y][linha_x].h == None and coluna_y <= 29 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].h == None:
                dist += 1
            coluna_y += 1
        if matriz_celula[coluna_y][linha_x].h != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x

#######################################################################################################################

def adiciona_vertice_o(ind_y, ind_x, ind_y_origem, ind_x_origem): # adiciona vertice ao conjunto O
    if matriz_celula[ind_y][ind_x].obstaculo == 0: #garante que se for vertice do obstaculo ele nao insere
        linha=0


        while vetor_conj_o[linha][0].coord_y_ponto != None: #verifica qual primeira posição vazia do vetor
            linha +=1
            if linha >= 99:
                linha = linha
        vetor_conj_o[linha][0].coord_y_ponto=ind_y
        vetor_conj_o[linha][0].coord_x_ponto=ind_x
        vetor_conj_o[linha][0].f = matriz_celula[ind_y][ind_x].f
        vetor_conj_o[linha][0].coord_y_origem = ind_y_origem
        vetor_conj_o[linha][0].coord_x_origem = ind_x_origem
        ordena_vetor_conj_o() #ordena o conjunto O

def adiciona_peso_g_vizinhos(ind_y, ind_x): #adiciona o peso g aos vizinhos
    #Prenche célula da direita
    #g é a distância da origem até o vertice n
    coord_x_origem = 2
    coord_y_origem = 2
    if ind_x<=10: #garante que ind_x não é a ultima célula da direita
        if matriz_celula[ind_y][ind_x+1].g == None and matriz_celula[ind_y][ind_x+1].obstaculo != 1:
            matriz_celula[ind_y][ind_x+1].g = sqrt((coord_x_origem-(ind_x+1))**2 + (coord_y_origem-ind_y)**2) #preenche g(n)
            matriz_celula[ind_y][ind_x + 1].f = matriz_celula[ind_y][ind_x+1].g + matriz_celula[ind_y][ind_x+1].h #f(n)=g(n)+h(n)

    #Prenche célula da esquerda
    if ind_x>=1: #garante que ind_x não é a primeira celula da esquerda
        if matriz_celula[ind_y][ind_x-1].g == None and matriz_celula[ind_y][ind_x-1].obstaculo != 1:
            matriz_celula[ind_y][ind_x-1].g = sqrt((coord_x_origem-(ind_x-1))**2 + (coord_y_origem-ind_y)**2) #preenche g(n)
            matriz_celula[ind_y][ind_x-1].f = matriz_celula[ind_y][ind_x-1].g + matriz_celula[ind_y][ind_x-1].h #f(n)=g(n)+h(n)

    #Preenche célula de cima
    if ind_y>=1: #garante que ind_y não é a primeira celula de cima
        if matriz_celula[ind_y-1][ind_x].g == None and matriz_celula[ind_y-1][ind_x].obstaculo != 1:
            matriz_celula[ind_y-1][ind_x].g = sqrt((coord_x_origem-(ind_x))**2 + (coord_y_origem-(ind_y-1))**2) #preenche g(n)
            matriz_celula[ind_y-1][ind_x].f = matriz_celula[ind_y-1][ind_x].g + matriz_celula[ind_y-1][ind_x].h #f(n)=g(n)+h(n)

    #Preenche célula de baixo
    if ind_y<=8: #garante que ind_y não é a ultima celula de baixo
        if matriz_celula[ind_y+1][ind_x].g == None and matriz_celula[ind_y+1][ind_x].obstaculo != 1:
            matriz_celula[ind_y+1][ind_x].g = sqrt((coord_x_origem-(ind_x))**2 + (coord_y_origem-(ind_y+1))**2) #preenche g(n)
            matriz_celula[ind_y+1][ind_x].f = matriz_celula[ind_y+1][ind_x].g + matriz_celula[ind_y+1][ind_x].h #f(n)=g(n)+h(n)

def verifica_em_c(ind_y, ind_x):
    # verifica se o vertice está em C
    esta = 0
    linhaC = 0
    while linhaC <= 199 and vetor_conj_c[linhaC][0].coord_y_ponto != None:
        if ind_y == vetor_conj_c[linhaC][0].coord_y_ponto:
            if ind_x == vetor_conj_c[linhaC][0].coord_x_ponto:
                esta = 1
                linhaC = 150
        linhaC += 1
    return(esta)

def retira_vertice_o():
    '''esta função retira o primeiro vertice do conjunto O e o coloca em C, caso ele ainda não esteja lá'''

    #verifica se o vertice está em C
    esta=0
    linhaC=0
    while linhaC<=199:
        if vetor_conj_o[0][0].coord_y_ponto == vetor_conj_c[linhaC][0].coord_y_ponto:
            if vetor_conj_o[0][0].coord_x_ponto == vetor_conj_c[linhaC][0].coord_x_ponto:
                esta=1
        linhaC +=1

    if esta==0: #se o vertice não estiver em C, adicione-o
        linhaC = 0
        while vetor_conj_c[linhaC][0].coord_y_ponto != None:  # verifica qual primeira posição vazia do vetor
            linhaC += 1
        vetor_conj_c[linhaC][0].coord_y_ponto = vetor_conj_o[0][0].coord_y_ponto
        vetor_conj_c[linhaC][0].coord_x_ponto = vetor_conj_o[0][0].coord_x_ponto
        vetor_conj_c[linhaC][0].f = vetor_conj_o[0][0].f
        vetor_conj_c[linhaC][0].coord_y_origem = vetor_conj_o[0][0].coord_y_origem
        vetor_conj_c[linhaC][0].coord_x_origem = vetor_conj_o[0][0].coord_x_origem

    linha=1 #retira o vertice de O
    while linha<=99:
        vetor_conj_o[linha-1][0].coord_y_ponto = vetor_conj_o[linha][0].coord_y_ponto
        vetor_conj_o[linha-1][0].coord_x_ponto = vetor_conj_o[linha][0].coord_x_ponto
        vetor_conj_o[linha-1][0].f = vetor_conj_o[linha][0].f
        vetor_conj_o[linha-1][0].coord_y_origem = vetor_conj_o[linha][0].coord_y_origem
        vetor_conj_o[linha-1][0].coord_x_origem = vetor_conj_o[linha][0].coord_x_origem
        linha += 1

def ordena_vetor_conj_o():
    l=0
    while l<=99 and vetor_conj_o[l][0].f != None:
        l1=l+1
        while l1<=99 and vetor_conj_o[l1][0].f != None:
            if vetor_conj_o[l1][0].f < vetor_conj_o[l][0].f:
                aux = vetor_conj_o[l][0].f
                aux2 = vetor_conj_o[l][0].coord_y_ponto
                aux3 = vetor_conj_o[l][0].coord_x_ponto
                aux4 = vetor_conj_o[l][0].coord_y_origem
                aux5 = vetor_conj_o[l][0].coord_x_origem
                vetor_conj_o[l][0].f = vetor_conj_o[l1][0].f
                vetor_conj_o[l][0].coord_y_ponto = vetor_conj_o[l1][0].coord_y_ponto
                vetor_conj_o[l][0].coord_x_ponto = vetor_conj_o[l1][0].coord_x_ponto
                vetor_conj_o[l][0].coord_y_origem = vetor_conj_o[l1][0].coord_y_origem
                vetor_conj_o[l][0].coord_x_origem = vetor_conj_o[l1][0].coord_x_origem
                vetor_conj_o[l1][0].f = aux
                vetor_conj_o[l1][0].coord_y_ponto = aux2
                vetor_conj_o[l1][0].coord_x_ponto = aux3
                vetor_conj_o[l1][0].coord_y_origem = aux4
                vetor_conj_o[l1][0].coord_x_origem = aux5
            l1 +=1
        l +=1

def crie_matriz_celula(n_linhas, n_colunas):  # cria uma matriz de objetos
    # Vamos criar uma matriz
    mat = []  # matriz vazia
    # Primeiro cria a linha
    for i in range(n_linhas):
        linha = []  # linha vazia, elementos
        for j in range(n_colunas):
            teste = Celula(i, j)
            linha.append(teste)  # adiciona o valor 0 na celula
        mat.append(linha)
    return mat

def crie_vetor_o(n_linhas, n_colunas):  # cria uma matriz de objetos
    # Vamos criar uma matriz
    matriz = []  # matriz vazia
    # Primeiro cria a linha
    for i in range(n_linhas):
        linha = []  # linha vazia, elementos
        for j in range(n_colunas):
            teste = Vetor(i, j)
            linha.append(teste)  # adiciona o valor 0 na celula
        matriz.append(linha)
    return matriz

def odometry_callback(data):
    global odometry  # definimos como variavel global
    #global q0, theta, k, d, x0, y0
    odometry = data  # pegamos o que chega em data e colocamos na variavel odometry
    #(roll, pitch, theta) = euler_from_quaternion([orient.x, orient.y, orient.z, orient.w])
    #x0 = data.pose.pose.position.x + d * cos(theta)
    #y0 = data.pose.pose.position.y + d * sin(theta)
    #q0 = np.array([x0, y0])
    #while q0 is None:
        #continue

# Cria uma função para receber os dados lidos de /base_scan. Os dados vem
# na variavel data
def laser_callback(data):
    global laser  # definimos como variavel global
    laser = data  # pegamos o que chega em data e colocamos em laser

#Busca o vertice que deu origem ao vertice pesquisado
def busca_origem(ind_y, ind_x):
    l=0
    while vetor_conj_c[l][0].coord_y_ponto!=None:
        if vetor_conj_c[l][0].coord_y_ponto == ind_y and vetor_conj_c[l][0].coord_x_ponto == ind_x:
            origemy = vetor_conj_c[l][0].coord_y_origem
            origemx = vetor_conj_c[l][0].coord_x_origem
            return origemy, origemx
        l += 1
    return origemy, origemx
# ========================================Iniciaremos o preenchimento da matriz célula=================================
#abrindo a imagem
obj_img_cenario:None = cv2.imread("/home/eudes/catkin_ws/src/trab2_questao1/worlds/cenario.pgm")
#plt.imshow(obj_img_cenario)
#plt.show()
# -------------------------------Inicia a identificação de obstaculo na celula-----------------------------------------
#####Inicia a definição de cada célula
##A celula sera uma matriz de 60x60 pixels
matriz_celula = crie_matriz_celula(10, 12)  # cria a matriz com cada celula
aux1_x = 0
indice_x = 0  # indice x da matriz celula maior 10x12 (altura x largura)
while aux1_x < 120:  # percorre as colunas
    aux1_y = 0
    indice_y = 0  # indice y  da matriz celula maior 10x12 (altura x largura)
    while aux1_y < 100:  # percorre as linhas
        tem_obstaculo = 0
        x = aux1_x

        while x < aux1_x + 10:
            y = aux1_y
            while y < aux1_y + 10:
                r, g, b = obj_img_cenario[y][x]  # retorna RGB
                if r != 255 or g != 255 or b != 255:  # se o pixel não for branco tem_obstaculo=1
                    tem_obstaculo = 1
                    #y = aux1_y + 20  # caso tenha achado algum pixel diferente de branco pula para próxima celula
                    #x = aux1_x + 20  # caso tenha achado algum pixel diferente de branco pula para próxima celula
                y += 1
            x += 1

        if tem_obstaculo == 0:
            matriz_celula[indice_y][indice_x].obstaculo = 0  # grava 0 caso não tenha obstaculo na celula
        if tem_obstaculo == 1:
            matriz_celula[indice_y][indice_x].obstaculo = 1  # grava 1 caso tenha obstaculo na celula

        indice_y += 1
        aux1_y = aux1_y + 10
    indice_x += 1
    aux1_x = aux1_x + 10


# -----------------------------------Fim da procura por obstáculo nas células ------------------------------------------

####################################Início da colocação das coordenadas das celulas ###################################

aux1_x = 0
while aux1_x < 12:
    aux1_y = 0
    while aux1_y < 10:
        matriz_celula[aux1_y][aux1_x].coord_x = aux1_x * 10 - 55  # calcula a coordenada x (em m)
        matriz_celula[aux1_y][aux1_x].coord_y = -aux1_y * 10 + 45  # calcula a coordenada y (em m)
        aux1_y += 1
    aux1_x += 1

# --------------------------------------Fim do cálculo das coordenadas das células -------------------------------------
###############################Início dos cálculos dos pesos############################################################
print("Início do cálculo dos pesos ...")

#Coordenada do alvo
coord_pixel_x=95
coord_pixel_y=25
cx=coord_pixel_x-60
cy=-coord_pixel_y+50
#Cálcula os índices das celulas onde está o alvo
c_dest_celula_y, c_dest_celula_x = calcula_coord_pixel(float(cy), float(cx))  # retorna os indices da matriz_celula onde está o destino


##########################################Inicia o cálculo de h(n) e g(n)#####################################################
'''A heuristica será a distancia entre o centro da celula destino e o vertice n'''
aux1_x=0
coord_x_destino=9
coord_y_destino=2
coord_x_origem = 2
coord_y_origem = 2
while aux1_x <= 11:
    aux1_y=0
    while aux1_y <= 9:
        if sqrt((coord_x_origem - aux1_x) ** 2 + (coord_y_origem - aux1_y) ** 2) != 0:
            matriz_celula[aux1_y][aux1_x].h = sqrt((coord_x_destino-aux1_x)**2 + (coord_y_destino-aux1_y)**2)
            matriz_celula[aux1_y][aux1_x].g = 1/sqrt((coord_x_origem - aux1_x) ** 2 + (coord_y_origem - aux1_y) ** 2)  # preenche g(n)
            matriz_celula[aux1_y][aux1_x].f = matriz_celula[aux1_y][aux1_x].g + matriz_celula[aux1_y][aux1_x].h  # f(n)=g(n)+h(n)
        else:
            matriz_celula[aux1_y][aux1_x].g = 0
        aux1_y +=1
    aux1_x +=1

################### Fim do cálculo de h #####################################################################

#Coordenada da origem
coord_orig_pixel_x=25 #coordenada x da origem em pixel
coord_orig_pixel_y=25 #coordenada y da origem em pixel
cx_orig=coord_orig_pixel_x-60 #coordenada x da origem em metros
cy_orig=-coord_orig_pixel_y+50 #coordenada y da origem em metros
#Cálcula os índices das celulas onde está o alvo
c_orig_celula_y, c_orig_celula_x = calcula_coord_pixel(float(cy_orig), float(cx_orig))  # retorna os indices da matriz_celula onde está a origem




################### Início da implementação do A* ############################################################

#Cria o conjunto O
vetor_conj_o = crie_vetor_o(100, 1) #cria 100 posições para o conjunto O
vetor_conj_c = crie_vetor_o(200, 1) #cria 200 posições para o conjunto O
#Vamos inserir no vetor_conj_o o primeiro nó
vetor_conj_o[0][0].coord_y_ponto = c_orig_celula_y
vetor_conj_o[0][0].coord_x_ponto = c_orig_celula_x
matriz_celula[c_orig_celula_y][c_orig_celula_x].g = 0 #atribui valor de g(n) = 0 para celula de origem
matriz_celula[c_orig_celula_y][c_orig_celula_x].f = matriz_celula[c_orig_celula_y][c_orig_celula_x].h
vetor_conj_o[0][0].f = matriz_celula[c_orig_celula_y][c_orig_celula_x].h
vetor_conj_o[0][0].coord_y_origem = c_orig_celula_y
vetor_conj_o[0][0].coord_x_origem = c_orig_celula_x
matriz_celula[c_orig_celula_y][c_orig_celula_x].visitado = 1 #indica que a celula foi visitada
matriz_celula[c_orig_celula_y][c_orig_celula_x].adicionado = 1 #indica que a celula foi adicionada em O
indice_y = c_orig_celula_y
indice_x = c_orig_celula_x

#Adicionar peso g nos vizinhos
adiciona_peso_g_vizinhos(indice_y, indice_x)

#Adiciona os vizinhos ao conjunto O
adiciona_vertice_o(indice_y+1, indice_x, indice_y, indice_x)
adiciona_vertice_o(indice_y-1, indice_x, indice_y, indice_x)
adiciona_vertice_o(indice_y, indice_x+1, indice_y, indice_x)
adiciona_vertice_o(indice_y, indice_x-1, indice_y, indice_x)
#ordena_vetor_conj_o()
retira_vertice_o()

linha=0

while vetor_conj_o[linha][0].coord_y_ponto != None and not(indice_x == c_dest_celula_x and indice_y == c_dest_celula_y):
    indice_x = vetor_conj_o[0][0].coord_x_ponto
    indice_y = vetor_conj_o[0][0].coord_y_ponto
    adiciona_peso_g_vizinhos(indice_y, indice_x)
    #Verifica de está em C
    retira_vertice_o()

    #Adiciona a célula inferior a O
    esta_em_c=0
    esta_em_c = verifica_em_c(indice_y+1, indice_x)
    if esta_em_c == 0:
        if indice_y<=8 and indice_x>=0: #garante que os indices não serão adicionados fora da faixa
            adiciona_vertice_o(indice_y+1, indice_x, indice_y, indice_x)

    # Adiciona a célula superior a O
    esta_em_c = 0
    esta_em_c = verifica_em_c(indice_y - 1, indice_x)
    if esta_em_c == 0:
        if indice_y >0 and indice_x >= 0:  # garante que os indices não serão adicionados fora da faixa
            adiciona_vertice_o(indice_y - 1, indice_x, indice_y, indice_x)

    # Adiciona a célula da direita a O
    esta_em_c = 0
    esta_em_c = verifica_em_c(indice_y, indice_x+1)
    if esta_em_c == 0:
        if indice_y >=0 and indice_x <= 10:  # garante que os indices não serão adicionados fora da faixa
                adiciona_vertice_o(indice_y, indice_x+1, indice_y, indice_x)

    # Adiciona a célula da esquerda a O
    esta_em_c = 0
    esta_em_c = verifica_em_c(indice_y, indice_x-1)
    if esta_em_c == 0:
        if indice_y >=0 and indice_x > 0:  # garante que os indices não serão adicionados fora da faixa
            adiciona_vertice_o(indice_y, indice_x - 1, indice_y, indice_x)

'''Até aqui montamos a matriz e calculamos os conjuntos O e C'''
#Agora iniciamos a montagem do vetor que guardará o caminho por onde o robô deve passar
vetor_caminho = crie_vetor_o(200, 1) #cria 200 posições para o caminho
linha=0
while vetor_conj_c[linha][0].coord_y_ponto != None:
    linha +=1 #quando sair do while "linha" terá o valor da ultima linha
vetor_caminho[0][0].coord_y_ponto = vetor_conj_c[linha-1][0].coord_y_ponto #preenche a primeira posição
vetor_caminho[0][0].coord_x_ponto = vetor_conj_c[linha-1][0].coord_x_ponto
origem_y, origem_x = busca_origem(vetor_caminho[0][0].coord_y_ponto, vetor_caminho[0][0].coord_x_ponto)
l=1
#enquanto não chegar a origem ele não para de rodar o loop
while not ((origem_y == c_orig_celula_y) and (origem_x == c_orig_celula_x)):
    vetor_caminho[l][0].coord_y_ponto = origem_y
    vetor_caminho[l][0].coord_x_ponto = origem_x
    origem_y, origem_x = busca_origem(vetor_caminho[l][0].coord_y_ponto, vetor_caminho[l][0].coord_x_ponto)
    l += 1
ultima_linha_caminho = l-1
######Fim da montagem do caminho

#######################################################################################################################
#######################################Início do robô##################################################################

# Vamos iniciar o determinação da posição original do robo
print('Iniciando o robô!')

rospy.init_node('trab_questao4', anonymous=False)

# Cria um tópico para ler os dados de odometria
rospy.Subscriber('/odom', Odometry, odometry_callback)

# Cria um tópico para ler os dados do scan
rospy.Subscriber('/base_scan', LaserScan, laser_callback)

# Cria um tópico para publicarmos a velocidade do robô
pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

# Enquanto estiver rodando ele vai publicar a informação de velociade
r = rospy.Rate(5)  # isto é um sleep para aliviar o processamento

# Criaremos uma variavel (velocity) que será a msg
# a ser publicada. Como vamos publicar ela em cmd_vel,
# esta tem que ser do tipo Twist.
velocity = Twist()  # isto é como se fosse uma declaração

erro_y = 0
erro_x = 0
d=0.5
k = 1000  # ganho para calculo de velecidade linear
aux2=ultima_linha_caminho
while not rospy.is_shutdown():
    orient = odometry.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([orient.x, orient.y, orient.z, orient.w])
    x0 = odometry.pose.pose.position.x + d * cos(theta)
    y0 = odometry.pose.pose.position.y + d * sin(theta)
    q0 = np.array([x0, y0])
    x = x0  # odometry.pose.pose.position.x
    y = y0  # odometry.pose.pose.position.y
    x_inicial = x0
    y_inicial = y0



    while aux2 >= 0 and (erro_y < 3 and erro_x < 3):
        indice_dest_robo_y = vetor_caminho[aux2][0].coord_y_ponto # recebe o indice y da matriz_caminho
        indice_dest_robo_x = vetor_caminho[aux2][0].coord_x_ponto # recebe o indice x da matriz_caminho
        yf = -10*indice_dest_robo_y+45  #coordenada em metros
        xf = 10*indice_dest_robo_x-55 #coordenada em metros
        aux2 -= 1
        erro_y = abs(yf - y)
        erro_x = abs(xf - x)

    erro_y = abs(yf - y)
    erro_x = abs(xf - x)

    print('Destino: y= ', yf, '    x= ', xf)
    print('Celula de destino: y=', indice_dest_robo_y, ' x=', indice_dest_robo_x)
    # print('Erro y: ', erro_y, 'Erro x: ', erro_x)
    # print('Arco tan: ', atan2((yf-y),(xf-x)))
    velocity.linear.x = k * (cos(theta) * (xf - q0[0]) + sin(theta) * (yf - q0[1]))
    velocity.angular.z = k * (-sin(theta) * (xf - q0[0]) / d + (cos(theta) * (yf - q0[1])) / d)

    pub.publish(velocity)
    # print('Vel linear: ', velocity.linear.x, ' Vel ang:', velocity.angular.z)
    r.sleep()



print('FIM')