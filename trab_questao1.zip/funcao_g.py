
#Preenche função g acima
def preenche_acima_g(coluna_y, linha_x):  # esta função irá preencher g das celulas acima
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and coluna_y > 0 and matriz_celula[coluna_y][linha_x].g != None:
        if matriz_celula[coluna_y - 1][linha_x].obstaculo == 0:
            matriz_celula[coluna_y - 1][linha_x].g = matriz_celula[coluna_y][linha_x].g + 1
            coluna_y -= 1
        else:
            coluna_y = 0

#Preenche a função g abaixo
def preenche_abaixo_g(coluna_y, linha_x):  # esta função irá preencher a função g das celulas a esquerda
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and coluna_y < 9 and matriz_celula[coluna_y][linha_x].g != None:
        if matriz_celula[coluna_y + 1][linha_x].obstaculo == 0:
            matriz_celula[coluna_y + 1][linha_x].g = matriz_celula[coluna_y][linha_x].g + 1
            coluna_y += 1
        else:
            coluna_y = 9

#preenche a função g a esquerda
def preenche_a_esquerda_g(coluna_y, linha_x):  # esta função irá preencher a função g das celulas a esquerda
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and linha_x > 0 and matriz_celula[coluna_y][linha_x].g != None:
        if matriz_celula[coluna_y][linha_x - 1].obstaculo == 0:
            matriz_celula[coluna_y][linha_x - 1].g = matriz_celula[coluna_y][linha_x].g + 1
            linha_x -= 1
        else:
            linha_x = 0

#Prenche a função g a direita
def preenche_a_direita_g(coluna_y, linha_x):  # esta função irá preencher a função g para as células a direita
    while matriz_celula[coluna_y][linha_x].obstaculo == 0 and linha_x < 11 and matriz_celula[coluna_y][linha_x].g != None:
        if matriz_celula[coluna_y][linha_x + 1].obstaculo == 0:
            matriz_celula[coluna_y][linha_x + 1].g = matriz_celula[coluna_y][linha_x].g + 1
            linha_x += 1
        else:
            linha_x = 11

def busca_celula_peso_esquerda_g(coluna_y, linha_x):  # esta função busca a primeira celula com peso a esquerda
    dist = 0
    achou = 0
    if linha_x != 0:  # se linha_x==0 nao faz sentido procurar celulas a esquerda
        while matriz_celula[coluna_y][linha_x].g == None and linha_x > 0 and matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].g == None:
                dist += 1
            linha_x -= 1
        if matriz_celula[coluna_y][linha_x].g != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x

def busca_celula_peso_direita_g(coluna_y, linha_x):  # esta função busca a primeira celula com peso a direita
    dist = 0
    achou = 0
    if linha_x != 11:  # se linha_x==29 nao faz sentido procurar celulas a direita
        while matriz_celula[coluna_y][linha_x].g == None and linha_x < 11 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].g == None:
                dist += 1
            linha_x += 1
        if matriz_celula[coluna_y][linha_x].g != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x

def busca_celula_peso_acima_g(coluna_y, linha_x):  # esta função busca a primeira celula com peso, acima
    dist = 0
    achou = 0
    if coluna_y != 0:  # se coluna_y==0 nao faz sentido procurar celulas acima
        while matriz_celula[coluna_y][linha_x].g == None and coluna_y >= 0 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].g == None:
                dist += 1
            coluna_y -= 1
        if matriz_celula[coluna_y][linha_x].g != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x


def busca_celula_peso_abaixo_g(coluna_y, linha_x):  # esta função busca a primeira celula com peso, abaixo
    dist = 0
    achou = 0
    if coluna_y != 29:  # se coluna_y==29 nao faz sentido procurar celulas abaixo
        while matriz_celula[coluna_y][linha_x].g == None and coluna_y <= 29 and \
                matriz_celula[coluna_y][linha_x].obstaculo != 1:
            if matriz_celula[coluna_y][linha_x].g == None:
                dist += 1
            coluna_y += 1
        if matriz_celula[coluna_y][linha_x].g != None:  # Caso ele saia do while por ter achado uma celula com peso, achou=1
            achou = 1

    if achou == 1:
        return dist, coluna_y, linha_x
    else:
        dist = 1000000  # Caso não tenha achado uma celula com peso, indica isso com dist=1.000.000
        return dist, coluna_y, linha_x


##########################################Inicia o cálculo de g(n)#####################################################
#Este cálculo parte da célula de origem
matriz_celula[c_orig_celula_y][c_orig_celula_x].g = 1
preenche_a_direita_g(c_orig_celula_y, c_orig_celula_x)
preenche_a_esquerda_g(c_orig_celula_y, c_orig_celula_x)
preenche_acima_g(c_orig_celula_y, c_orig_celula_x)
preenche_abaixo_g(c_orig_celula_y, c_orig_celula_x)

# ----Vamos iniciar a preencher as celulas fora da linha da celula destino
print('   Colocando peso nas células a partir da linha e coluna da célula origem ...')
ref_x = c_orig_celula_x  # recebe o valor do eixo x da celula origem
ref_y = c_orig_celula_y  # recebe o valor do eixo y da celula origem
ref_x -= 1  # desloco para esquerda
# Neste while abaixo vamos percorrer as células a esquerda da celula destino e preencher as celulas acima e abaixo delas
while matriz_celula[ref_y][ref_x].obstaculo != 1 and ref_x >= 0:
    if matriz_celula[ref_y][ref_x].obstaculo != 1 and matriz_celula[ref_y][ref_x].g != None:
        preenche_acima_g(ref_y, ref_x)
        preenche_abaixo_g(ref_y, ref_x)
    ref_x -= 1

# Agora começamos a preencher as demais celulas
print('   Colocando peso nas demais células ...')
print('      ++Esquerda - Direita ...')
aux1_x = 0
while aux1_x <= 11:
    aux1_y = 0
    while aux1_y <= 9:
        if matriz_celula[aux1_y][aux1_x].g == None and matriz_celula[aux1_y][aux1_x].obstaculo == 0:  # se for uma celula obstaculo pula pra próxima
            distancia_cel, coord_y, coord_x = busca_celula_peso_esquerda_g(aux1_y, aux1_x)
            if distancia_cel != 1000000:
                preenche_a_direita_g(coord_y, coord_x)
            else:
                distancia_cel, coord_y, coord_x = busca_celula_peso_direita_g(aux1_y, aux1_x)
                if distancia_cel != 1000000:
                    preenche_a_esquerda_g(coord_y, coord_x)
        aux1_y += 1
    aux1_x += 1

print('      ++Acima - Abaixo ...')
aux1_x = 0
while aux1_x <= 11:
    aux1_y = 0
    while aux1_y <= 9:
        if matriz_celula[aux1_y][aux1_x].g == None and matriz_celula[aux1_y][aux1_x].obstaculo == 0:  # se for uma celula obstaculo pula pra próxima
            distancia_cel, coord_y, coord_x = busca_celula_peso_acima_g(aux1_y, aux1_x)
            if distancia_cel != 1000000:
                preenche_abaixo_g(coord_y, coord_x)
            else:
                distancia_cel, coord_y, coord_x = busca_celula_peso_abaixo_g(aux1_y, aux1_x)
                if distancia_cel != 1000000:
                    preenche_acima_g(coord_y, coord_x)
        aux1_y += 1
    aux1_x += 1

print('   Fim do cálculo de g e preenchimento dos pesos das células!')
################### Fim do cálculo de g #####################################################################

################### Calcula a função f ######################################################################
print('Início do preenchimento da função f=g+h')
aux1_x = 0
while aux1_x <= 11:
    aux1_y = 0
    while aux1_y <= 9:
        if matriz_celula[aux1_y][aux1_x].g != None and matriz_celula[aux1_y][aux1_x].obstaculo == 0 and matriz_celula[aux1_y][aux1_x].h != None:
            matriz_celula[aux1_y][aux1_x].f = matriz_celula[aux1_y][aux1_x].g + matriz_celula[aux1_y][aux1_x].h
        aux1_y +=1
    aux1_x +=1
print('Fim do preenchimento da função f=g+h')
################### Fim do cálculo de f ######################################################################