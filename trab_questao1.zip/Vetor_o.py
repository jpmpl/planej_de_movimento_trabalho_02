class Vetor:
#    coord_x_ponto = None  # indica a coordenada x do ponto inserido em O
#   coord_y_ponto=None #indica a coordenada y do ponto inserido em O
#    f=None #indica peso f da célula - função f(n)=g(n)+h(n)
#    coord_x_origem=None #coordenada x da célula de onde veio até esta celula
#    coord_y_origem = None  # coordenada x da célula de onde veio até esta celula
    def __init__(self, eixo_x, eixo_y):
        self.coord_x_ponto=None #indica a coordenada x do ponto inserido em O
        self.coord_y_ponto=None #indica a coordenada y do ponto inserido em O
        self.f=None #indica peso f da célula - função f(n)=g(n)+h(n)
        self.coord_x_origem=None #coordenada x da célula de onde veio até esta celula
        self.coord_y_origem = None  # coordenada y da célula de onde veio até esta celula