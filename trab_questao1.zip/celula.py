class Celula:
    def __init__(self, eixo_x, eixo_y):
        self.obstaculo=None #indica se há obstaculo nesta celula
        self.distancia_para_alvo=None
        self.coord_y=None #coordenada y da célula em metros
        self.coord_x=None #coordenada x da célula em metros
        self.g=None #função g(n)
        self.h=None #função h(n)
        self.f=None  # função f(n)=g(n)+h(n)
        self.visitado=None #indica se essa célula já foi visitada caso = 1
        self.adicionado = None  # indica se essa célula já foi adicionada em O caso = 1